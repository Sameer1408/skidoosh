import React,{useState,useRef} from 'react'
import emailjs from "@emailjs/browser"

function ContactForm() {

    const form = useRef();
    const [name, setName] = useState("");
    const [company, setCompany] = useState("");
    const [email, setEmail] = useState("");
    const [number, setNumber] = useState("");
    const [country, setCountry] = useState("");
    const [service, setService] = useState("");

    const sendEmail = (e) => {
        // setThanks(true);
        e.preventDefault();
        // emailjs.sendForm('service_4iytwqd', 'template_pptnbt9', form.current, 'o24Fc3Wsy3dQZti08')
        emailjs.sendForm('', '', form.current, '')
          .then((result) => {
            // history.push('/thanks')
          }, (error) => {
            alert("please try again some error occurred");
          });
      };
    


    return (
        <div>
            <section>
                <div class="formDiv container" >
                    <h1 class="formHeading" style={{marginBottom:"50px",fontWeight:"100"}}>Contact us Form</h1>
                    <form ref={form} onSubmit={sendEmail}>

                        <label for="fname">Your Name</label>
                        <input class="inp form-control" type="text" name="name" value={name} onChange={(e) => { setName(e.target.value) }} />

                        <label for="fname">Company</label>
                        <input class="inp form-control" type="text" name="company" value={company} onChange={(e) => { setCompany(e.target.value) }} />

                        <label for="fname">Email Id</label>
                        <input class="inp form-control" type="email" name="email" value={email} onChange={(e) => { setEmail(e.target.value) }} />

                        <label for="fname">Contact Number</label>
                        <input class="inp form-control" type="number" name="number" value={number} onChange={(e) => { setNumber(e.target.value) }} />

                        <label for="fname">Country</label>
                        <input class="inp form-control" type="text" name="country" value={country} onChange={(e) => { setCountry(e.target.value) }} />

                        <label for="fname">Service Required</label>
                        <input class="inp form-control" type="text" name="service" value={service} onChange={(e) => { setService(e.target.value) }} />

                        <input className="trendBtn" type="submit" value="Book Your Free Consultation today" />
                    </form>

                </div>
            </section>
        </div>
    )
}

export default ContactForm