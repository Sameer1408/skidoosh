import React from 'react'

function Clientel() {
    return (
        <div className="container" style={{marginTop:"100px",marginBottom:"100px"}} >

            <h1 style={{marginBottom:"100px",fontWeight:"100"}}>Our Clientele</h1>
         
            <div class="container" style={{ marginBottom: "150px" }}>
                <div class="row">
                    <div class="col-sm">
                        <div className="ClientImg1">
                        </div>

                    </div>
                    <div class="col-sm">
                        <div className="ClientImg2">
                        </div>
                    </div>
                    <div class="col-sm">
                        <div className="ClientImg3"></div>
                    </div>
                    <div class="col-sm">
                        <div className="ClientImg4"></div>
                    </div>
                    <div class="col-sm">
                        <div className="ClientImg5"></div>
                    </div>
                </div>
            </div>

       
          
        </div>
    )
}

export default Clientel