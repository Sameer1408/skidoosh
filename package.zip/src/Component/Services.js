import React from 'react'

function Services() {
    return (
        <div style={{marginTop:"150px"}}>
            <div class="container">
            <h1 className="container" style={{fontWeight:100}}>But How!</h1>
                <div class="row">
                  
                    <div class="col-sm" style={{ textAlign: "right",padding:"40px"}}>
                        <h4 style={{ display: "inline" }}>001.</h4>
                        <h1 style={{ display: "inline" ,fontSize:"48px"}}>Performance Marketing </h1>
                        <p style={{ textAlign: "justify", fontSize: "20px", marginTop: "10px" }}>Constantly achieving ROAS of more than 25 Times every month. That’s enough to tell that our paid game is good.</p>
                  
                        <h4 style={{ display: "inline" }}>004.</h4>
                        <h1 style={{ display: "inline",fontSize:"48px" }}>SEO</h1>
                        <p style={{ textAlign: "justify", fontSize: "20px" }}>Want traffic on your website, but don’t want to pay for Performance Marketing ? We got your cover with our Strong suite of SEO.</p>
                    </div>

                    <div class="col-sm" style={{ textAlign: "right",padding:"40px" }}>
                        <h4 style={{ display: "inline" }}>002.</h4>
                        <h1 style={{ display: "inline" ,fontSize:"48px",lineHeight:"0.8"}}>Social Media Marketing </h1>
                        <p style={{ textAlign: "justify", fontSize: "20px" }}>Lifting your brand from being transparent to an overnight sensation with our Social Media Campaign. Roads to Instagram Richness !
                        </p>
                    </div> 

                    <div class="col-sm" style={{ textAlign: "right" ,padding:"40px"}}>
                        <h4 style={{ display: "inline" }}>003.</h4>
                        <h1 style={{ display: "inline" ,fontFamily:"48px"}}>Web Development</h1>
                        <p style={{ textAlign: "justify", fontSize: "20px" }}>“ Soo Appealing “ “ Works really well ! “ “ Much better than I could think of “. Yes, we had them saying these after seeing the website we developed.
                        </p>
                    </div>
                </div>
            </div>


            {/* <hr style={{ width: "95%", border: "1px solid grey", marginBottom: "100px" }}></hr> */}
        </div>
    )
}

export default Services