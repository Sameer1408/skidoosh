import React, { useEffect, useState, useRef } from 'react';
import Clientel from './Clientel';
import ContactForm from './ContactForm';
import Services from './Services';
import logo from "../images/Logo3.png"
function Home({ }) {
    // const dispatch = useDispatch();
    // const getPics = async () => {
    //     dispatch(getPicsAction(page))
    // }
    const pointer = useRef();
    const [showNav, setShowNav] = useState(false);
    const [up, setUp] = useState(true);

    const listenScroll = () => {

        let hieghtToHidden = 400;
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;

        if (hieghtToHidden <= winScroll) {
            setShowNav(true);
            setUp(true);
        }
        else {
            setShowNav(false);
            setUp(false);
        }

        window.onscroll = function (e) {
            console.log(this.oldScroll > this.scrollY, "direction");
            if (this.oldScroll > this.scrollY) {
                setUp(true);
            }
            else {
                setUp(false);
            }
            this.oldScroll = this.scrollY;
        }

        console.log(winScroll, "winScroll");
        pointer.current.style.top = pointer?.current?.style?.top + winScroll + "px";

    };

    useEffect(() => {
        window.addEventListener("scroll", listenScroll);
    }, []);


    return (
        <>
            <div ref={pointer} >
                <div
                    className={showNav ? "topN2" : "topN1"}>
                    <img
                        className={showNav ? "logo1" : "logo0"}
                        src={logo}
                    >
                    </img>
                </div>
                

                <div class="" style={{ textAlign: "center", marginBottom: "100px" }}>
                    <div class="row" style={{ width: "100%" }}>
                        <div class="col-sm col-lg-4" style={{ textAlign: "center", border: "1px solid transparent" }}>

                        </div>
                        <div class="col-sm  col-lg-4" style={{ textAlign: "center", border: "1px solid transparent" }}>
                            <h1 className="topHeading">We Convert Restaurant into High Revenue Generating Entities</h1>
                        </div>
                        <div class="col-sm col-lg-4" style={{ textAlign: "center", border: "1px solid transparent" }}>
                            <div className="chefImg"></div>
                        </div>
                    </div>
                </div>
                <div>
                    <h1 className="container weDo" style={{ fontWeight: 100 }}>What We Do ..</h1>
                    <h1 style={{ fontSize: "120px", margin: "90px", textAlign: "center", fontWeight: "400" }}>We Bring FootFall To Your Restaurants Like Never Before</h1>
                </div>
                <Services />
                <Clientel />
                <ContactForm />
            </div>
        </>
    )
}

export default Home